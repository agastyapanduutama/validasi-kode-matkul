
<div class="card">
    <div class="card-header">
        <h5>Daftar Matakuliah Baru ditambahkan</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="list_matkul" class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Kode Matakuliah</th>
                        <th>Nama Matakuliah</th>
                        <th>SKS</th>
                        <th>Tahun Kurikulum</th>
                        <th>Aksi</th>
                </thead>
                <tbody>
                   
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Kode Matakuliah</th>
                        <th>Nama Matakuliah</th>
                        <th>SKS</th>
                        <th>Tahun Kurikulum</th>
                        <th>Aksi</th>
                </tfoot>
            </table>
        </div>
    </div>
</div>